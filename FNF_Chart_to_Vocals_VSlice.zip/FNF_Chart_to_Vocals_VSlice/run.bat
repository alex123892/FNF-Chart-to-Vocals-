@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
py fnf_chart_to_vocals.py
pause
