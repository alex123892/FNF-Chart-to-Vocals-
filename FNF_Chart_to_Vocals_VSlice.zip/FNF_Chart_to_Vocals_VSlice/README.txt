FNF Chart to Vocals Generator - V-Slice edition

Instalacion:
1. Extrae el ZIP completo a una carpeta.
2. Instala Python 3.
3. Instala FluidSynth y FFmpeg y agregalos al PATH de Windows.
4. Ejecuta run.bat.

Uso:
1. En Chart JSON, selecciona el archivo V-Slice *-chart.json.
2. Si tenes el metadata del tema (*-metadata.json), seleccionalo tambien.
   Es opcional y se usa para nombrar la pista del oponente con su ID real,
   por ejemplo Voices-dad.ogg.
3. Selecciona el SF2 de BF y el SF2 del oponente.
4. Elige la dificultad.
5. Pulsa GENERATE VOCALS.

Compatibilidad V-Slice:
- El chart V-Slice guarda las dificultades en el objeto "notes".
- Cada nota usa t = tiempo en ms, d = lane/strumline data y l = sustain.
- d 0-3 corresponde al jugador/BF; d 4-7 corresponde al oponente.
- La app permite elegir la dificultad desde las claves de "notes".

Importante:
- El programa sintetiza notas MIDI usando cada SF2. No reconstruye por si solo
  las sílabas vocales originales de BF o del oponente.
- El mapeo inicial de las 4 direcciones es MIDI 60, 62, 64 y 65.
- Los charts V-Slice guardan notas y metadata en archivos separados:
  *-chart.json contiene las notas.
  *-metadata.json contiene personajes, BPM y dificultades.

Control de volumen vocal:
- La interfaz incluye "Aumento de volumen vocal (dB)".
- El valor inicial es +8 dB y se puede cambiar entre 0 y 18 dB.
- El mismo aumento se aplica a BF y al oponente.
- Se añade un limitador para evitar que los picos superen aproximadamente -0.45 dBFS.
